
package br.maua._maua_poo_l6_pessoas;

import java.sql.*;
public class TesteConexao {
    public static void main(String[] args) {
        String host = "localhost";
        String porta = "3306";
        String database = "20231_maua_poo_l6_pessoas";
        String usuario = "root";
        String senha = "1234"; //mysqlimt
        String stringConexao = String.format(
            "jdbc:mysql://%s:%s/%s?useTimezone=true&serverTimezone=America/Sao_Paulo",
            host,
            porta,
            database
        );
        try{
            Connection conexao = DriverManager.getConnection(
                stringConexao,
                usuario,
                senha
            );
            System.out.println("Conexão OK");
        }
        catch(Exception e){
            System.out.println("Conexão NOK");
            System.out.println(e.getMessage());
        }
        
    }
}
