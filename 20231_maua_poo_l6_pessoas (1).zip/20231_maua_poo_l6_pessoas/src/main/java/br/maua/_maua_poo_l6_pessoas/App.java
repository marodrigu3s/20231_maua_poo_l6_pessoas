package br.maua._maua_poo_l6_pessoas;
public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
