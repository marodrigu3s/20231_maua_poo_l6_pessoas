package br.maua._maua_poo_l6_pessoas;
import java.sql.*;
public class PessoaDAO {
    void cadastrar(Pessoa p)throws Exception {
        //passo 1: especificar o comando SQL
        String sql = "Insert into tb_pessoa (nome, fone, email) values (?, ?, :)";
        //passo 2: abrir uma conexão como banco
        Connection conexao = ConnectionFactory.obterConexao();
        //passo 3: preparar comando
        PreparedStatement ps = conexao.prepareStatement(sql);
        //passo 4: substituir os eventuais placeholders
        ps.setString(1, p.getNome());
        ps.setString(2, p.getFone());
        ps.setString(3, p.getEmail());
        //passo 5: executar o comando
        ps.execute();
        //passo 6: fechar as coisas (deslocar recursos)
        ps.close();
        conexao.close();
    }
}
