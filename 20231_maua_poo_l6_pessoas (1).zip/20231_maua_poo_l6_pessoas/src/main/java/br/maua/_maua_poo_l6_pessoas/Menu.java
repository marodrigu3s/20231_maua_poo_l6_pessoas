package br.maua._maua_poo_l6_pessoas;
public class Menu {
    public static void main(String[] args) {
        String nome = "Ana";
        String fone = "12345678";
        String email = "ana@gmail.com";
        var p = new Pessoa();
        p.setNome(nome);
        p.setFone(fone);
        p.setEmail(email);
        
        //1. construir um objeto do tipo PessoaDAO
        var pessoadao = new PessoaDAO();
        //2. chamar o método cadastrar
        pessoadao.cadastrar();
        //Dica: lembre-se de usar try/catch 
    }
}
