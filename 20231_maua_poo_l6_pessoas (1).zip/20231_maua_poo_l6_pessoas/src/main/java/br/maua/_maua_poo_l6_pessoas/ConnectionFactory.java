package br.maua._maua_poo_l6_pessoas;
import java.sl.*;
public class ConnectionFactory {
    static Connection obterConexao()throws Exception {
        String host = "localhost";
        String porta = "3306";
        String database = "20231_maua_poo_l6_pessoas";
        String usuario = "root";
        String senha = "mysqlimt"; 
        String stringConexao = String.format(
            "jdbc:mysql://%s:%s/%s?useTimezone=true&serverTimezone=America/Sao_Paulo",
            host,
            porta,
            database
        );
        return DriverManager.getConnection(
                stringConexao,
                usuario,
                senha
        );
        //cláusula catch or declare   
    }
}
